<?php

namespace backend\modules\profile\actions;

use yii\base\Action;

class CheckAccess extends Action
{
//  for update own


}