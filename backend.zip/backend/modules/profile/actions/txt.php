<?php

$auth = Yii::$app->authManager;

// 1. Базовые права на просмотр профилей
$viewProfiles = $auth->createPermission('viewProfiles');
$viewProfiles->description = 'Просмотр профилей пользователей';
$auth->add($viewProfiles);
