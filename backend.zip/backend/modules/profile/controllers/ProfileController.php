<?php

namespace backend\modules\profile\controllers;

use backend\modules\profile\actions\CreateProfileAction;
use backend\modules\profile\actions\GetProfileAction;
use backend\modules\profile\actions\UpdateProfileAction;
use yii\web\Controller;

class ProfileController extends Controller
{
    public $defaultAction = 'profile';

   public function actions(){
        return [
            'profile'=>GetProfileAction::class,
            'create'=>CreateProfileAction::class,
            'update'=>UpdateProfileAction::class,
        ];
   }

}